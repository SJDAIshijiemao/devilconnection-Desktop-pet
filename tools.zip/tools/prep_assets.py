#!/usr/bin/env python3
"""把 Ral-德比伦 的中文素材目录规范化成 Android assets。

做三件事：
1. 中文目录/文件名 → ASCII 路径（AssetsManager 加载更稳，避免编码坑）
2. 按透明边界裁剪 + 缩放到合适尺寸（原图 1280x960，全量 79MB 太大）
3. 生成 assets/sprites/manifest.json，Java 侧按这份表读取，不再依赖中文路径
"""
import json
import os
import shutil
import sys

from PIL import Image

SRC = "/root/userdata/workspace/zongchong/Ral-德比伦"
DST = "/root/userdata/workspace/ralseint/app/src/main"
ASSETS = os.path.join(DST, "assets")
MAX_H = 720          # 宠物贴图最大高度
MICRO_MAX_H = 260    # 微表情贴图最大高度


# 中文表情组 → (ASCII 组名, 状态键)
GROUPS = [
    ("表情库/待机时", "idle", "idle", MAX_H),
    ("表情库/吃东西", "eat", "eat", MAX_H),            # 特殊：里面还有 吃完了 子目录
    ("表情库/生气时", "angry", "angry", MAX_H),
    ("表情库/懒洋洋的", "lazy", "lazy", MAX_H),
    ("表情库/高兴", "happy", "happy", MAX_H),
    ("表情库/杂鱼", "zayu", "zayu", MAX_H),
    ("表情库/看向左", "look_left", "look_left", MAX_H),
    ("表情库/看向右", "look_right", "look_right", MAX_H),
    ("表情库/懵", "dazed", "dazed", MAX_H),
    ("表情库/吸取魔力", "magic", "magic", MAX_H),
    ("表情库/惊讶时", "surprise", "surprise", MAX_H),
    ("表情库/吓人", "scare", "scare", MAX_H),
    ("表情库/思考", "think", "think", MAX_H),
    ("微表情", "micro", "micro", MICRO_MAX_H),
]

# 主设计里 AI 会用的括号标签 → 状态键（"…" 与 "~" 等尾巴由 Java 侧归一化）
TAGS = {
    "吃东西": "eat", "生气": "angry", "懒洋洋": "lazy", "高兴": "happy",
    "杂鱼": "zayu", "困": "lazy", "看向左": "look_left", "看向右": "look_right",
    "晕": "micro_dizzy", "棒": "happy", "懵": "dazed", "吸取魔力": "magic",
    "惊讶": "surprise", "吓人": "scare", "思考": "think",
}

# 微表情文件名 → ASCII
MICRO_MAP = {"急": "anxious", "晕": "dizzy", "杂鱼": "zayu", "生气": "angry", "高兴": "happy"}


def slug(name):
    return name


def trim_and_save(im, max_h):
    """裁掉全透明边距，再等比缩放到 max_h 以内。"""
    if im.mode != "RGBA":
        im = im.convert("RGBA")
    bbox = im.getchannel("A").getbbox()
    if bbox:
        pad = 4
        bbox = (max(0, bbox[0] - pad), max(0, bbox[1] - pad),
                min(im.width, bbox[2] + pad), min(im.height, bbox[3] + pad))
        im = im.crop(bbox)
    if im.height > max_h:
        w = int(round(im.width * max_h / im.height))
        im = im.resize((w, max_h), Image.LANCZOS)
    return im


def handle_group(rel, group, key, max_h, manifest):
    src = os.path.join(SRC, rel)
    if not os.path.isdir(src):
        print("  ! 缺少目录:", rel)
        return
    entries = []
    # 1) 直属图片
    flat = sorted(f for f in os.listdir(src) if f.lower().endswith(".png"))
    subdir = os.path.join(src, "吃完了")
    for i, f in enumerate(flat):
        ascii_dir = "sprites/" + group
        if group == "eat" and f.startswith("吃东西"):
            out = "sprites/eat/eating.png"
            state = "eat"
        elif group == "eat":
            out = "sprites/eat/misc%d.png" % i
            state = "eat"
        else:
            stem = f.rsplit(".", 1)[0]
            name = MICRO_MAP.get(stem, stem) if group == "micro" else "%s%d" % (group, i + 1)
            if group == "micro":
                out = "sprites/micro/%s.png" % name
            else:
                out = "sprites/%s/%s.png" % (group, name)
            state = key
        process(os.path.join(src, f), os.path.join(ASSETS, out), max_h)
        entries.append(out)
        if group == "micro":
            manifest.setdefault("micro", {})[name.rsplit("_", 1)[0] if False else MICRO_MAP.get(stem, stem)] = out
    # 2) 吃东西/吃完了
    if os.path.isdir(subdir):
        for i, f in enumerate(sorted(x for x in os.listdir(subdir) if x.lower().endswith(".png"))):
            out = "sprites/eat/done%d.png" % (i + 1)
            process(os.path.join(subdir, f), os.path.join(ASSETS, out), max_h)
            entries.append(out)
    manifest.setdefault("states", {})[key] = entries
    return entries


def process(src_file, dst_file, max_h):
    os.makedirs(os.path.dirname(dst_file), exist_ok=True)
    try:
        im = Image.open(src_file)
    except Exception as e:
        print("  ! 打开失败", src_file, e)
        return
    im = trim_and_save(im, max_h)
    im.save(dst_file, "PNG", optimize=True)


def main():
    if os.path.isdir(ASSETS):
        shutil.rmtree(ASSETS)
    os.makedirs(ASSETS, exist_ok=True)
    manifest = {"states": {}, "micro": {}, "tags": TAGS}

    for rel, group, key, max_h in GROUPS:
        handle_group(rel, group, key, max_h, manifest)

    # 纯文本资产
    shutil.copy(os.path.join(SRC, "AI提示词.md"), os.path.join(ASSETS, "prompt.txt"))
    shutil.copy(os.path.join(SRC, "主设计.txt"), os.path.join(ASSETS, "design.txt"))
    agree = os.path.join(SRC, "软件协议与用户声明")
    names = {"软件协议.md": "agreement_software.txt", "用户协议.md": "agreement_user.txt"}
    for f, out in names.items():
        p = os.path.join(agree, f)
        if os.path.exists(p):
            shutil.copy(p, os.path.join(ASSETS, out))

    # po.mp3 → res/raw/po.mp3（Android 资源名必须小写 ASCII）
    rawdir = os.path.join(DST, "res/raw")
    os.makedirs(rawdir, exist_ok=True)
    shutil.copy(os.path.join(SRC, "po.mp3"), os.path.join(rawdir, "po.mp3"))

    with open(os.path.join(ASSETS, "sprites/manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=1)

    total = 0
    for r, _, fs in os.walk(ASSETS):
        for f in fs:
            total += os.path.getsize(os.path.join(r, f))
    print("assets 总字节: %.2f MB" % (total / 1048576.0))
    print("状态数:", len(manifest["states"]), {k: len(v) for k, v in manifest["states"].items()})
    print("微表情:", manifest["micro"])


if __name__ == "__main__":
    main()
