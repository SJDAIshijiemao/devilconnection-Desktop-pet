package ralseint.emolianjie.com;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class UiSizeTest {

    @Test
    public void defaultDialogFitsSmallPhone() {
        int w = UiSize.dialogWidthDp(UiSize.DEFAULT_DIALOG_SCALE);
        int h = UiSize.dialogHeightDp(UiSize.DEFAULT_DIALOG_SCALE);
        assertTrue("默认宽度应 <= 210dp，实际 " + w, w <= 210);
        assertTrue("默认高度应 <= 250dp，实际 " + h, h <= 250);
    }

    @Test
    public void dialogNeverSmallerThanUsableSize() {
        assertTrue(UiSize.dialogWidthDp(UiSize.MIN_DIALOG_SCALE) >= 150);
        assertTrue(UiSize.dialogHeightDp(UiSize.MIN_DIALOG_SCALE) >= 170);
    }
}
