package ralseint.emolianjie.com;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

/**
 * 用户反馈：AI 输出 :(向右看…)好吧。 这类变体时，检测不能失灵（原实现只认设计稿里的死字符串）。
 */
public class TagParserTest {

    @Test
    public void recognisesColonPrefixedHalfWidthParen() {
        TagParser.Hit h = TagParser.parse("杂~~~~~鱼~~:(向右看…)好吧。");
        assertNotNull("带冒号的半角括号要能识别", h);
        assertEquals("look_right", h.state);
    }

    @Test
    public void recognisesAliasVariants() {
        assertEquals("look_right", TagParser.parse("看右边！(向右看)").state);
        assertEquals("look_left", TagParser.parse("(往左看…)").state);
        assertEquals("eat", TagParser.parse("(吃东西了)").state);
        assertEquals("happy", TagParser.parse("(开心~)").state);
        assertEquals("angry", TagParser.parse("(气死我了)").state);
        assertEquals("dazed", TagParser.parse("(懵圈)").state);
        assertEquals("magic", TagParser.parse("(吸收魔力…)").state);
        assertEquals("surprise", TagParser.parse("(吃惊！)").state);
        assertEquals("scare", TagParser.parse("(吓吓你)").state);
        assertEquals("think", TagParser.parse("(让我想想…)").state);
        assertEquals("lazy", TagParser.parse("(好困)").state);
    }

    @Test
    public void skipsUnknownParenAndTakesNextKnownTag() {
        TagParser.Hit h = TagParser.parse("(注：本大爷心情不错)(高兴~)");
        assertNotNull(h);
        assertEquals("happy", h.state);
    }

    @Test
    public void unbalancedParenDoesNotHangOrMatch() {
        assertNull(TagParser.parse("(生气 没关括号"));
        assertNull(TagParser.parse("没有括号的生气"));
        assertNull(TagParser.parse(""));
        assertNull(TagParser.parse(null));
    }
}
