package ralseint.emolianjie.com;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/** 刚聊过天不能被判定成冷场：AI 的回复也算活动 */
public class IdleArbiterTest {

    private static final long LIMIT = 120_000L;

    @Test
    public void freshAiReplyCountsAsActivity() {
        long now = 1_000_000L;
        long lastUser = now - 200_000L;
        long lastAi = now - 3_000L;
        assertFalse(IdleArbiter.shouldSpeakNow(now, lastUser, lastAi, false, true, LIMIT));
    }

    @Test
    public void firesWhenBothSidesSilent() {
        long now = 1_000_000L;
        assertTrue(IdleArbiter.shouldSpeakNow(now, now - 200_000L, now - 200_000L,
                false, true, LIMIT));
    }

    @Test
    public void neverFiresWhileBusyOrNoPet() {
        long now = 1_000_000L;
        assertFalse(IdleArbiter.shouldSpeakNow(now, 0, 0, true, true, LIMIT));
        assertFalse(IdleArbiter.shouldSpeakNow(now, 0, 0, false, false, LIMIT));
    }
}
