package ralseint.emolianjie.com;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PositionModelTest {

    private static final int SCREEN_W = 1080;
    private static final int SCREEN_H = 2400;
    private static final int PET_W = 300;
    private static final int PET_H = 560;
    private static final int TOP = 72;
    private static final int BOTTOM = 120;

    private PositionModel model() {
        PositionModel m = new PositionModel();
        m.setBounds(SCREEN_W, SCREEN_H, PET_W, PET_H, TOP, BOTTOM);
        return m;
    }

    @Test
    public void bobDoesNotSnapDraggedPetBackToSpawnPoint() {
        PositionModel m = model();
        m.setBase(600, 1008);
        m.setBase(200, 300);
        m.setFloatOffset(-42);
        assertEquals(200, m.x());
        assertEquals(258, m.y());
        m.setFloatOffset(0);
        assertEquals(300, m.y());
    }

    @Test
    public void petCanBePlacedTopAndBottomOfScreen() {
        PositionModel m = model();
        m.setFloatOffset(0);
        m.setBase(0, 0);
        assertEquals(TOP, m.y());
        m.setBase(99999, 99999);
        assertEquals(SCREEN_W - PET_W, m.x());
        assertEquals(SCREEN_H - PET_H - BOTTOM, m.y());
    }

    @Test
    public void roamTargetInsideWholeScreen() {
        PositionModel m = model();
        m.setBase(0, m.minY());
        assertEquals(m.minY(), m.y());
        m.setBase(m.maxX(), m.maxY());
        assertEquals(m.maxX(), m.x());
        assertEquals(m.maxY(), m.y());
    }
}
