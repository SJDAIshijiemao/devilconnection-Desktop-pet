package ralseint.emolianjie.com;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * 用户报的"刚说过话还被提醒冷场"：一次性旁白不能被当作用户原话留在上下文里。
 */
public class ContextBuilderTest {

    private List<ChatStore.Msg> history() {
        List<ChatStore.Msg> l = new ArrayList<>();
        l.add(new ChatStore.Msg("user", "你好", "user"));
        l.add(new ChatStore.Msg("assistant", "喂，干嘛(高兴~)", "ai"));
        l.add(new ChatStore.Msg("user", "（已经超过约 2 分钟没有和召唤师说话了…）", "notice"));
        l.add(new ChatStore.Msg("assistant", "你怎么又不说话啦", "ai"));
        return l;
    }

    @Test
    public void noticeIsNeverSentAsUserUtterance() {
        List<ContextBuilder.Turn> turns = ContextBuilder.build("规则", history(), 12, null);
        for (ContextBuilder.Turn t : turns) {
            assertFalse("notice 混进了用户消息，模型会反复复读冷场提示",
                    "user".equals(t.role) && t.content.contains("没有和召唤师说话"));
        }
    }

    @Test
    public void realTurnsKeptInOrder() {
        List<ContextBuilder.Turn> turns = ContextBuilder.build("规则", history(), 12, null);
        assertEquals("system", turns.get(0).role);
        int real = 0;
        boolean hasUser = false;
        for (int i = 1; i < turns.size(); i++) {
            if (!"system".equals(turns.get(i).role)) {
                real++;
            }
            if ("user".equals(turns.get(i).role)) {
                hasUser = true;
            }
        }
        assertTrue("真实用户消息必须保留", hasUser);
        assertEquals("旁白不进上下文，只剩 3 条真实轮次", 3, real);
    }

    @Test
    public void oneShotInstructionGoesAsSystemTurnAtEnd() {
        List<ContextBuilder.Turn> turns = ContextBuilder.build("规则", history(), 12, "冷场了，主动说话");
        ContextBuilder.Turn last = turns.get(turns.size() - 1);
        assertEquals("system", last.role);
        assertEquals("冷场了，主动说话", last.content);
    }
}
