package ralseint.emolianjie.com;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 德比伦本体：悬浮窗服务。
 * 负责宠物贴图、上下浮动、可拖动、四处游走、右上角微表情、对话框、
 * 情绪标签落地、吃东西三秒流程、保活定时请求、静默超时主动搭话、前台应用检测。
 * 一次只允许存在一个德比伦（本服务实例内单视图）。
 */
public class PetService extends Service {

    public static final String ACTION_SUMMON = "ralseint.SUMMON";
    public static final String ACTION_RECALL = "ralseint.RECALL";
    public static final String ACTION_REFRESH = "ralseint.REFRESH";
    /** 用户声明页的 debug 按钮：不连 API，直接走一遍输出管线 */
    public static final String ACTION_DEBUG = "ralseint.DEBUG";

    private static final int NOTI_ID = 73001;
    private static final String CHANNEL = "ralseint_pet";

    private WindowManager wm;
    private Prefs prefs;
    private SpriteStore sprites;
    private ChatStore store;
    private AiClient ai;
    private final Handler h = new Handler(Looper.getMainLooper());

    private ImageView petImage;
    private View petView;
    private WindowManager.LayoutParams petLp;
    private int petW, petH;

    private ImageView microImage;
    private View microView;
    private WindowManager.LayoutParams microLp;
    private int microW, microH;

    private View chatView;
    private WindowManager.LayoutParams chatLp;
    private ListView chatList;
    private EditText input;
    private MsgAdapter adapter;
    private final List<ChatStore.Msg> msgs = new ArrayList<>();

    private MediaPlayer po;
    private boolean busy;
    private String sessionId = "";
    private String systemRule = "";
    private long lastUserTs = 0L;
    /** AI 上一次回复时间，和 lastUserTs 一起参与冷场判定 */
    private long lastAiTs = 0L;
    /** 一次性指令：随下一次请求发出后立刻作废，不进历史 */
    private String pendingInstruction = null;
    /** 情绪贴图的展示保护期，期内不允许待机轮播踩掉它 */
    private long holdUntil = 0L;
    private int idleTick = 0;
    private int debugIdx = 0;

    private final PositionModel model = new PositionModel();
    private int floatOffset = 0;
    private android.animation.ValueAnimator bob;
    private android.animation.ValueAnimator roam;

    private final Runnable keepAlive = new Runnable() {
        @Override
        public void run() {
            if (prefs != null) {
                AiClient.Config c = AiClient.Config.of(prefs);
                if (c.model != null && !c.model.isEmpty()) {
                    ai.ping(c, new AiClient.OnPing() {
                        @Override
                        public void done(boolean alive, String err) {
                            // 保活结果不打扰用户，只在日志里留痕
                            android.util.Log.d("ralseint", "keepalive " + (alive ? "ok" : err));
                        }
                    });
                }
            }
            h.postDelayed(this, Math.max(1, prefs.keepAliveMinutes()) * 60000L);
        }
    };

    private final Runnable heartbeat = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            long limit = Math.max(1, prefs.autoTalkMinutes()) * 60000L;
            if (IdleArbiter.shouldSpeakNow(now, lastUserTs, lastAiTs, busy, petView != null, limit)) {
                // 触发后把基准推到当下，形成迟滞，避免连着抢话
                lastUserTs = now;
                addNotice("（已经超过约 " + prefs.autoTalkMinutes()
                        + " 分钟没有和召唤师说话了，请主动找他说话，短句、口语化，可以带一个括号表情）");
            }
            scanForegroundApp();
            h.postDelayed(this, 15000);
        }
    };

    /** 每 5 秒换一张待机图，每 4 次顺带弹个右上角小表情，桌面更活 */
    private final Runnable idleTicker = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            if (petView != null && !busy && now > holdUntil) {
                setSprite(sprites.pick(SpriteStore.S_IDLE));
                idleTick++;
                if (idleTick % 4 == 0) {
                    String key = sprites.randomMicroKey();
                    if (key != null) {
                        showMicro(key);
                    }
                }
            }
            h.postDelayed(this, 5000);
        }
    };

    private final Runnable revertIdle = new Runnable() {
        @Override
        public void run() {
            setSprite(sprites.pick(SpriteStore.S_IDLE));
        }
    };

    private final Runnable hideMicro = new Runnable() {
        @Override
        public void run() {
            hideMicroView();
        }
    };

    // 前台应用检测：主设计要求识别抖音、快手等并向 AI 报告
    private static final String[] WATCH_PKGS = {
            "com.ss.android.ugc.aweme",   // 抖音
            "com.ss.android.ugc.aweme.lite",
            "com.smile.gifmaker",         // 快手
            "com.kuaishou.nebula",
    };
    private long usageSince = System.currentTimeMillis();
    private String lastWatched = "";
    private long lastWatchNotify = 0L;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = new Prefs(this);
        sprites = new SpriteStore(this);
        store = new ChatStore(this);
        ai = new AiClient();
        systemRule = readAsset("prompt.txt");
        sessionId = store.ensure(prefs.session());
        prefs.session(sessionId);
        lastUserTs = System.currentTimeMillis();
        startNoti();
    }

    @Override
    public int onStartCommand(Intent it, int flags, int startId) {
        String a = it == null ? null : it.getAction();
        if (ACTION_RECALL.equals(a)) {
            recallAll();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_REFRESH.equals(a)) {
            if (petView != null) {
                applySizes();
            }
            return START_STICKY;
        }
        if (ACTION_DEBUG.equals(a)) {
            if (petView == null) {
                attachPet();
            }
            debugDemo();
            return START_STICKY;
        }
        // ACTION_SUMMON：一次只能召唤一个，已存在就只把对话框带到面前
        if (petView == null) {
            attachPet();
            greetIfNeeded();
        } else {
            showChat();
        }
        h.removeCallbacks(keepAlive);
        h.postDelayed(keepAlive, Math.max(1, prefs.keepAliveMinutes()) * 60000L);
        h.removeCallbacks(heartbeat);
        h.postDelayed(heartbeat, 15000);
        h.removeCallbacks(idleTicker);
        h.postDelayed(idleTicker, 5000);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        recallAll();
        if (po != null) {
            try {
                po.release();
            } catch (Exception ignored) {
            }
            po = null;
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ 通知

    private void startNoti() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        int fl = Build.VERSION.SDK_INT >= 23
                ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, fl);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification n = b.setContentTitle("德比伦在桌面上")
                .setContentText("点我回到设置")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        try {
            startForeground(NOTI_ID, n);
        } catch (Exception e) {
            android.util.Log.w("ralseint", "startForeground 失败: " + e);
        }
    }

    // ------------------------------------------------------------------ 悬浮宠物

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private int screenW() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenH() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private void attachPet() {
        Bitmap first = sprites.pick(SpriteStore.S_IDLE);
        if (first == null) {
            toast("表情素材没找到，请确认 assets/sprites 是否打包进 APK");
            return;
        }
        petImage = new ImageView(this);
        petImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        petImage.setAdjustViewBounds(false);
        petImage.setImageBitmap(first);

        int base = (int) dp(190);
        petW = Math.max(1, (int) (base * (first.getWidth() / (double) first.getHeight())));
        petH = base;

        petLp = new WindowManager.LayoutParams(petW, petH, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        petLp.gravity = Gravity.TOP | Gravity.START;
        syncBounds();
        int px = prefs.petX() >= 0 ? prefs.petX() : screenW() - petW - (int) dp(20);
        int py = prefs.petY() >= 0 ? prefs.petY() : model.clampY((int) (screenH() * 0.5f));
        model.setBase(model.clampX(px), py);

        petView = petImage;
        installDrag();
        wm.addView(petView, petLp);
        startBob();
        scheduleRoam();
    }

    /** 屏幕可用区边界：上方留状态栏，下方留导航条 */
    private void syncBounds() {
        model.setBounds(screenW(), screenH(), petW, petH, (int) dp(28), (int) dp(64));
    }

    private int clampX(int x) {
        return model.clampX(x);
    }

    private int clampY(int y) {
        return model.clampY(y);
    }

    /** 唯一写 window 坐标的出口：任何动画/拖动都只能改基准或偏移，再由这里合成 */
    private void applyPos() {
        if (petView == null) {
            return;
        }
        petLp.x = model.x();
        petLp.y = model.y();
        wm.updateViewLayout(petView, petLp);
        updateMicroPos();
        if (chatView != null) {
            updateChatPos();
        }
    }

    private void installDrag() {
        final float[] down = new float[2];
        final int[] start = new int[2];
        final boolean[] moved = {false};
        petView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        down[0] = e.getRawX();
                        down[1] = e.getRawY();
                        start[0] = model.baseX();
                        start[1] = model.baseY();
                        moved[0] = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - down[0];
                        float dy = e.getRawY() - down[1];
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved[0] = true;
                            cancelRoam();
                        }
                        if (moved[0]) {
                            model.setBase(start[0] + (int) dx, start[1] + (int) dy);
                            applyPos();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (!moved[0]) {
                            toggleChat();
                        } else {
                            prefs.petPos(model.x(), model.y());
                            scheduleRoam();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    /** 上下悬浮：无论如何都保持漂浮 */
    private void startBob() {
        if (bob != null) {
            bob.cancel();
        }
        bob = android.animation.ValueAnimator.ofInt(0, -(int) dp(14));
        bob.setDuration(1400);
        bob.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        bob.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        bob.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        bob.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                floatOffset = (Integer) a.getAnimatedValue();
                model.setFloatOffset(floatOffset);
                applyPos();
            }
        });
        bob.start();
    }

    /** 四处移动 */
    private void scheduleRoam() {
        h.removeCallbacks(roofRoamTask);
        if (!prefs.roaming()) {
            return;
        }
        h.postDelayed(roofRoamTask, 4000 + (long) (Math.random() * 6000));
    }

    private final Runnable roofRoamTask = new Runnable() {
        @Override
        public void run() {
            if (petView == null || !prefs.roaming()) {
                return;
            }
            syncBounds();
            int tx = model.minX() + (int) (Math.random() * Math.max(1, model.maxX() - model.minX()));
            int ty = model.minY() + (int) (Math.random() * Math.max(1, model.maxY() - model.minY()));
            roam = android.animation.ValueAnimator.ofFloat(0f, 1f);
            roam.setDuration(3200 + (long) (Math.random() * 2600));
            final int fx = model.baseX(), fy = model.baseY();
            roam.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(android.animation.ValueAnimator a) {
                    float p = (Float) a.getAnimatedValue();
                    model.setBase((int) (fx + (tx - fx) * p), (int) (fy + (ty - fy) * p));
                    applyPos();
                }
            });
            roam.start();
            prefs.petPos(model.x(), model.y());
            h.postDelayed(this, roam.getDuration() + 5000 + (long) (Math.random() * 9000));
        }
    };

    private void cancelRoam() {
        if (roam != null) {
            roam.cancel();
            roam = null;
        }
        h.removeCallbacks(roofRoamTask);
    }

    private void setSprite(Bitmap b) {
        if (b == null || petImage == null) {
            return;
        }
        petImage.setImageBitmap(b);
        int base = (int) dp(190);
        int w = Math.max(1, (int) (base * (b.getWidth() / (double) b.getHeight())));
        if (w != petW) {
            petW = w;
            petLp.width = w;
            syncBounds();
            applyPos();
        }
    }

    /** 按设置里的百分比重算宠物与对话框大小 */
    private void applySizes() {
        if (petView == null) {
            return;
        }
        Bitmap cur = peekSprite();
        if (cur != null) {
            int base = (int) dp(190 * prefs.petScale() / 100f);
            petH = base;
            petW = Math.max(1, (int) (base * (cur.getWidth() / (double) cur.getHeight())));
            petLp.width = petW;
            petLp.height = petH;
            syncBounds();
            applyPos();
        }
        if (chatView != null) {
            chatLp.width = (int) dp(UiSize.dialogWidthDp(prefs.dialogScale()));
            chatLp.height = (int) dp(UiSize.dialogHeightDp(prefs.dialogScale()));
            wm.updateViewLayout(chatView, chatLp);
        }
    }

    private Bitmap peekSprite() {
        if (petImage.getDrawable() instanceof android.graphics.drawable.BitmapDrawable) {
            return ((android.graphics.drawable.BitmapDrawable) petImage.getDrawable()).getBitmap();
        }
        return null;
    }

    // ------------------------------------------------------------------ 微表情

    private void showMicro(String key) {
        if (key == null || !sprites.hasMicro(key)) {
            return;
        }
        Bitmap b = sprites.micro(key);
        if (b == null) {
            return;
        }
        microW = (int) (dp(74) * prefs.petScale() / 100f);
        microH = Math.max(1, (int) (microW * (b.getHeight() / (double) b.getWidth())));
        if (microView == null) {
            microImage = new ImageView(this);
            microImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
            microView = microImage;
            microLp = new WindowManager.LayoutParams(microW, microH, overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            microLp.gravity = Gravity.TOP | Gravity.START;
            try {
                wm.addView(microView, microLp);
            } catch (Exception e) {
                microView = null;
                return;
            }
        }
        microImage.setImageBitmap(b);
        microLp.width = microW;
        microLp.height = microH;
        microView.setVisibility(View.VISIBLE);
        updateMicroPos();
        h.removeCallbacks(hideMicro);
        h.postDelayed(hideMicro, 3000);   // 每个微表情只显示 3 秒，期间可被替换
    }

    private void updateMicroPos() {
        if (microView == null || petView == null) {
            return;
        }
        microLp.x = clampX(petLp.x + petW - microW / 2);
        microLp.y = clampY(petLp.y) - microH / 3;
        try {
            wm.updateViewLayout(microView, microLp);
        } catch (Exception ignored) {
        }
    }

    private void hideMicroView() {
        if (microView != null) {
            microView.setVisibility(View.GONE);
        }
    }

    // ------------------------------------------------------------------ 对话框

    private void toggleChat() {
        if (chatView == null) {
            showChat();
        } else {
            hideChat();
        }
    }

    private void showChat() {
        if (chatView != null || petView == null) {
            return;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke((int) dp(1), Color.parseColor("#DDDDDD"));
        root.setBackground(bg);
        root.setPadding((int) dp(8), (int) dp(6), (int) dp(8), (int) dp(6));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("德比伦");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.parseColor("#222222"));
        title.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button newSess = smallButton("新对话");
        newSess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newSession();
            }
        });
        Button close = smallButton("收起");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideChat();
            }
        });
        head.addView(title);
        head.addView(newSess);
        head.addView(close);
        root.addView(head);

        chatList = new ListView(this);
        chatList.setDivider(null);
        chatList.setCacheColorHint(Color.TRANSPARENT);
        adapter = new MsgAdapter();
        chatList.setAdapter(adapter);
        root.addView(chatList, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this);
        input.setHint("跟德比伦说点什么…");
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setMaxLines(3);
        input.setSingleLine(false);
        row.addView(input, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button send = smallButton("发送");
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = input.getText().toString().trim();
                if (t.isEmpty()) {
                    return;
                }
                input.setText("");
                sendUser(t);
            }
        });
        row.addView(send);
        root.addView(row);

        chatLp = new WindowManager.LayoutParams(
                (int) dp(UiSize.dialogWidthDp(prefs.dialogScale())),
                (int) dp(UiSize.dialogHeightDp(prefs.dialogScale())),
                overlayType(),
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        chatLp.gravity = Gravity.TOP | Gravity.START;
        chatLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
        root.setFocusableInTouchMode(true);
        root.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    hideChat();
                    return true;
                }
                return false;
            }
        });
        chatView = root;
        reloadMessages();
        updateChatPos();
        wm.addView(chatView, chatLp);
        chatList.post(new Runnable() {
            @Override
            public void run() {
                chatList.setSelection(adapter.getCount() - 1);
            }
        });
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setAllCaps(false);
        b.setPadding((int) dp(6), 0, (int) dp(6), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, (int) dp(34)));
        return b;
    }

    private void updateChatPos() {
        if (chatView == null || petView == null) {
            return;
        }
        int x = petLp.x - chatLp.width - (int) dp(8);
        if (x < (int) dp(4)) {
            x = Math.min(petLp.x + petW + (int) dp(8), screenW() - chatLp.width - (int) dp(4));
        }
        chatLp.x = Math.max((int) dp(4), x);
        chatLp.y = Math.min(Math.max((int) dp(24), petLp.y), Math.max((int) dp(24), screenH() - chatLp.height - (int) dp(24)));
        try {
            wm.updateViewLayout(chatView, chatLp);
        } catch (Exception ignored) {
        }
    }

    private void hideChat() {
        if (chatView != null) {
            try {
                wm.removeView(chatView);
            } catch (Exception ignored) {
            }
            chatView = null;
            chatList = null;
            input = null;
        }
    }

    private void recallAll() {
        if (idleTicker != null) {
            h.removeCallbacks(idleTicker);
        }
        cancelRoam();
        if (bob != null) {
            bob.cancel();
            bob = null;
        }
        hideChat();
        removeSafely(microView);
        removeSafely(petView);
        microView = null;
        petView = null;
    }

    private void removeSafely(View v) {
        if (v != null) {
            try {
                wm.removeView(v);
            } catch (Exception ignored) {
            }
        }
    }

    // ------------------------------------------------------------------ 会话与消息

    private void greetIfNeeded() {
        if (store.count(sessionId) == 0) {
            // 主设计：刚召唤出助手时要自动发送“规矩”
            addNotice("（规矩已载入。请按你的设定向召唤师打个招呼，短句即可）");
        } else {
            reloadMessages();
        }
    }

    private void newSession() {
        sessionId = store.create();
        prefs.session(sessionId);
        msgs.clear();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
        addNotice("（召唤师开启了一段新对话，请重新打招呼）");
    }

    private void sendUser(String text) {
        lastUserTs = System.currentTimeMillis();
        persist("user", text, "user");
        requestReply();
    }

    /**
     * 程序旁白：界面显示一条灰色说明，同时把这句话作为一次性 system 指令发给模型。
     * 它不能以 role=user 进入历史，否则会被当召唤师原话反复复读（用户报的冷场提示就是这个原因）。
     */
    private void addNotice(String text) {
        pendingInstruction = text;
        persist("user", text, "notice");
        requestReply();
    }

    private void persist(String role, String content, String kind) {
        ChatStore.Msg m = new ChatStore.Msg(role, content, kind);
        store.append(sessionId, m);
        msgs.add(m);
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            if (chatList != null) {
                chatList.setSelection(adapter.getCount() - 1);
            }
        }
    }

    private void reloadMessages() {
        msgs.clear();
        msgs.addAll(store.load(sessionId));
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private JSONArray buildContext() {
        String instruction = pendingInstruction;
        pendingInstruction = null;          // 一次性，用完即焚
        JSONArray arr = new JSONArray();
        try {
            for (ContextBuilder.Turn t : ContextBuilder.build(
                    systemRule, msgs, prefs.contextLimit(), instruction)) {
                JSONObject o = new JSONObject();
                o.put("role", t.role);
                o.put("content", t.content);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        return arr;
    }

    private void requestReply() {
        if (busy) {
            toast("德比伦还在想上一句…");
            return;
        }
        AiClient.Config cfg = AiClient.Config.of(prefs);
        if (cfg.model == null || cfg.model.isEmpty()) {
            toast("先在设置里选好模型");
            return;
        }
        busy = true;
        setSprite(sprites.hasState(SpriteStore.S_THINK)
                ? sprites.pick(SpriteStore.S_THINK) : sprites.pick(SpriteStore.S_IDLE));
        ai.chat(cfg, buildContext(), new AiClient.OnReply() {
            @Override
            public void done(String text, String err) {
                busy = false;
                if (err != null) {
                    lastAiTs = System.currentTimeMillis();
                    persist("assistant", "连接失败：" + err, "notice");
                    setSprite(sprites.pick(SpriteStore.S_IDLE));
                    return;
                }
                String clean = text == null ? "" : text;
                lastAiTs = System.currentTimeMillis();
                persist("assistant", clean, "ai");
                playVoice();
                applyEmotion(clean);
            }
        });
    }

    /** 情绪标签 → 身体贴图 + 右上角微表情；吃东西有 3 秒流程 */
    private void applyEmotion(String text) {
        TagParser.Hit hit = TagParser.parse(text);
        h.removeCallbacks(revertIdle);
        if (hit == null) {
            setSprite(sprites.pick(SpriteStore.S_IDLE));
            microFromTone(text);
            return;
        }
        holdUntil = System.currentTimeMillis() + (hit.isEat() ? 7000 : 6000);
        if (hit.isEat()) {
            Bitmap eating = sprites.pick(SpriteStore.S_EAT);
            setSprite(eating);
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    setSprite(sprites.pickEaten());
                    // 主设计：三秒吃完后向服务器发一条“已经吃完了”的对话
                    addNotice("（德比伦已经吃完了，请继续）");
                    h.postDelayed(revertIdle, 4000);
                }
            }, 3000);
        } else if (hit.state != null && sprites.hasState(hit.state)) {
            setSprite(sprites.pick(hit.state));
            h.postDelayed(revertIdle, 6000);
        } else {
            setSprite(sprites.pick(SpriteStore.S_IDLE));
            h.postDelayed(revertIdle, 6000);
        }
        if (hit.micro != null) {
            showMicro(hit.micro);
        } else {
            microFromTone(text);
        }
    }

    /** 没有显式标签时，按语气关键词判断右上角微表情（主设计：根据 API 心情和语气判断） */
    private void microFromTone(String text) {
        if (text == null) {
            return;
        }
        String t = text;
        if (t.matches("(?s).*(哼|可恶|烦死|别吵|滚).*")) {
            showMicro("angry");
        } else if (t.matches("(?s).*(哈|爽|不错|算你|棒).*")) {
            showMicro("happy");
        } else if (t.matches("(?s).*(等下|等等|别靠|快|慌).*")) {
            showMicro("anxious");
        } else if (t.matches("(?s).*杂鱼.*")) {
            showMicro("zayu");
        } else if (t.matches("(?s).*(晕|扶我).*")) {
            showMicro("dizzy");
        }
    }

    /** debug 按钮用：依次输出内置测试句，验证音效、贴图、微表情、气泡滚动 */
    private static final String[] DEBUG_LINES = {
            "杂~~~~~鱼~~，这是声音测试，听得到吗(高兴~)",
            "我要开吃了~(吃东西)",
            "喂，那明显是什么造型！反人类设计好吧！(晕)",
            "你看右边！(向右看…)",
            "等等、等等！别、别靠这么近！(懵)",
            "麻烦死了……还要收集魔力(懒洋洋…)",
    };

    private void debugDemo() {
        String line = DEBUG_LINES[debugIdx % DEBUG_LINES.length];
        debugIdx++;
        lastAiTs = System.currentTimeMillis();
        persist("assistant", "【测试" + debugIdx + "/" + DEBUG_LINES.length + "】" + line, "ai");
        playVoice();
        applyEmotion(line);
    }

    private void playVoice() {
        if (!prefs.sound()) {
            return;
        }
        try {
            if (po == null) {
                po = MediaPlayer.create(this, R.raw.po);
            }
            if (po != null) {
                if (po.isPlaying()) {
                    po.seekTo(0);
                } else {
                    po.start();
                }
            }
        } catch (Exception e) {
            android.util.Log.w("ralseint", "po.mp3 播放失败: " + e);
        }
    }

    // ------------------------------------------------------------------ 前台应用检测

    @SuppressLint("ObsoleteSdkInt")
    private void scanForegroundApp() {
        if (petView == null || Build.VERSION.SDK_INT < 21) {
            return;
        }
        try {
            android.app.usage.UsageStatsManager us =
                    (android.app.usage.UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (us == null) {
                return;
            }
            long now = System.currentTimeMillis();
            android.app.usage.UsageEvents ev = us.queryEvents(usageSince, now);
            usageSince = now;
            android.app.usage.UsageEvents.Event e = new android.app.usage.UsageEvents.Event();
            String found = null;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND
                        || e.getEventType() == 1) {
                    for (String pkg : WATCH_PKGS) {
                        if (pkg.equals(e.getPackageName())) {
                            found = pkg;
                        }
                    }
                }
            }
            if (found != null && !found.equals(lastWatched)
                    && now - lastWatchNotify > 60000 && !busy) {
                lastWatched = found;
                lastWatchNotify = now;
                String name = found.contains("aweme") ? "抖音" : "快手";
                addNotice("（召唤师正在刷" + name + "，这属于日常普通玩闹，你可以顺着聊两句）");
            }
        } catch (Exception ignored) {
            // 没给“使用情况访问权限”时静默跳过
        }
    }

    // ------------------------------------------------------------------ 小工具

    private String readAsset(String name) {
        try {
            java.io.InputStream in = getAssets().open(name);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) > 0) {
                bo.write(buf, 0, r);
            }
            in.close();
            return new String(bo.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void toast(String s) {
        if (s == null || s.isEmpty()) {
            return;
        }
        h.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Toast.makeText(PetService.this, s, Toast.LENGTH_SHORT).show();
                } catch (Exception ignored) {
                }
            }
        });
    }

    /** 聊天气泡适配器：用户靠右、德比伦靠左、程序叙述居中浅灰 */
    private class MsgAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return msgs.size();
        }

        @Override
        public Object getItem(int i) {
            return msgs.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View conv, android.view.ViewGroup parent) {
            ChatStore.Msg m = msgs.get(pos);
            TextView tv = (conv instanceof TextView) ? (TextView) conv : new TextView(PetService.this);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13 * prefs.dialogScale() / 100f);
            tv.setPadding((int) dp(10), (int) dp(7), (int) dp(10), (int) dp(7));
            tv.setText(m.content);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(12));
            int maxw = (int) (chatLp == null ? dp(240) : chatLp.width * 0.82f);
            tv.setMaxWidth(maxw);
            if ("notice".equals(m.kind)) {
                tv.setTextColor(Color.parseColor("#888888"));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
                bg.setColor(Color.parseColor("#F4F4F4"));
                lp.gravity = Gravity.CENTER_HORIZONTAL;
            } else if ("user".equals(m.role)) {
                tv.setTextColor(Color.WHITE);
                bg.setColor(Color.parseColor("#4A6FE3"));
                lp.gravity = Gravity.END;
            } else {
                tv.setTextColor(Color.parseColor("#222222"));
                bg.setColor(Color.parseColor("#EFEFEF"));
                lp.gravity = Gravity.START;
            }
            tv.setBackground(bg);
            lp.topMargin = (int) dp(4);
            lp.bottomMargin = (int) dp(4);
            tv.setLayoutParams(lp);
            return tv;
        }
    }
}
