package ralseint.emolianjie.com;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 解析 AI 回复里的括号情绪标签。主设计规定"只有括号才有效"，
 * 但模型实际会写成 :(向右看…)好吧。 / (吃东西了) / (好困) 这类变体，
 * 原来只做死字符串精确匹配，变体一律落空，看起来就像检测卡死。
 *
 * 现在：归一化（去 …~!。等尾巴）→ 精确匹配 → 最长别名包含匹配；
 * 一个括号不认识就继续找下一个，括号不闭合不会挂，也不会误匹配。
 */
public final class TagParser {

    public static class Hit {
        public String state;
        public String micro;
        public String raw;

        public boolean isEat() {
            return SpriteStore.S_EAT.equals(state);
        }
    }

    /** 别名（已归一化）→ {身体状态, 微表情}，越靠前优先级越高 */
    private static final Map<String, String[]> ALIAS = new LinkedHashMap<>();

    static {
        String E = SpriteStore.S_EAT, A = SpriteStore.S_ANGRY, L = SpriteStore.S_LAZY;
        String H = SpriteStore.S_HAPPY, Z = SpriteStore.S_ZAYU, LL = SpriteStore.S_LOOK_LEFT;
        String LR = SpriteStore.S_LOOK_RIGHT, D = SpriteStore.S_DAZED, M = SpriteStore.S_MAGIC;
        String S = SpriteStore.S_SURPRISE, SC = SpriteStore.S_SCARE, T = SpriteStore.S_THINK;

        ALIAS.put("吃东西", new String[]{E, null});
        ALIAS.put("吃东西了", new String[]{E, null});
        ALIAS.put("吃了", new String[]{E, null});
        ALIAS.put("吃一口", new String[]{E, null});
        ALIAS.put("吃完", new String[]{E, null});
        ALIAS.put("生气", new String[]{A, "angry"});
        ALIAS.put("气死", new String[]{A, "angry"});
        ALIAS.put("气坏", new String[]{A, "angry"});
        ALIAS.put("恼火", new String[]{A, "angry"});
        ALIAS.put("火大", new String[]{A, "angry"});
        ALIAS.put("懒洋洋", new String[]{L, null});
        ALIAS.put("好累", new String[]{L, null});
        ALIAS.put("不想动", new String[]{L, null});
        ALIAS.put("好困", new String[]{L, null});
        ALIAS.put("困了", new String[]{L, null});
        ALIAS.put("困", new String[]{L, null});
        ALIAS.put("想睡", new String[]{L, null});
        ALIAS.put("高兴", new String[]{H, "happy"});
        ALIAS.put("开心", new String[]{H, "happy"});
        ALIAS.put("愉快", new String[]{H, "happy"});
        ALIAS.put("心情不错", new String[]{H, "happy"});
        ALIAS.put("爽", new String[]{H, "happy"});
        ALIAS.put("棒", new String[]{H, "happy"});
        ALIAS.put("好棒", new String[]{H, "happy"});
        ALIAS.put("厉害", new String[]{H, "happy"});
        ALIAS.put("赞", new String[]{H, "happy"});
        ALIAS.put("杂鱼", new String[]{Z, "zayu"});
        ALIAS.put("菜鸡", new String[]{Z, "zayu"});
        ALIAS.put("弱鸡", new String[]{Z, "zayu"});
        ALIAS.put("看向左", new String[]{LL, null});
        ALIAS.put("向左看", new String[]{LL, null});
        ALIAS.put("往左看", new String[]{LL, null});
        ALIAS.put("看左边", new String[]{LL, null});
        ALIAS.put("看左", new String[]{LL, null});
        ALIAS.put("望左", new String[]{LL, null});
        ALIAS.put("看向右", new String[]{LR, null});
        ALIAS.put("向右看", new String[]{LR, null});
        ALIAS.put("往右看", new String[]{LR, null});
        ALIAS.put("看右边", new String[]{LR, null});
        ALIAS.put("看右", new String[]{LR, null});
        ALIAS.put("望右", new String[]{LR, null});
        ALIAS.put("吸取魔力", new String[]{M, null});
        ALIAS.put("吸收魔力", new String[]{M, null});
        ALIAS.put("收集魔力", new String[]{M, null});
        ALIAS.put("吸魔", new String[]{M, null});
        ALIAS.put("惊讶", new String[]{S, null});
        ALIAS.put("吃惊", new String[]{S, null});
        ALIAS.put("震惊", new String[]{S, null});
        ALIAS.put("吓人", new String[]{SC, "anxious"});
        ALIAS.put("吓你", new String[]{SC, "anxious"});
        ALIAS.put("吓吓你", new String[]{SC, "anxious"});
        ALIAS.put("吓一跳", new String[]{SC, "anxious"});
        ALIAS.put("思考", new String[]{T, null});
        ALIAS.put("想想", new String[]{T, null});
        ALIAS.put("让我想想", new String[]{T, null});
        ALIAS.put("琢磨", new String[]{T, null});
        ALIAS.put("懵", new String[]{D, "anxious"});
        ALIAS.put("懵圈", new String[]{D, "anxious"});
        ALIAS.put("发懵", new String[]{D, "anxious"});
        ALIAS.put("呆住", new String[]{D, "anxious"});
        ALIAS.put("晕", new String[]{null, "dizzy"});   // 表情库无"晕"，只出微表情
        ALIAS.put("头晕", new String[]{null, "dizzy"});
        ALIAS.put("晕倒", new String[]{null, "dizzy"});
    }

    private TagParser() {
    }

    public static String normalize(String s) {
        if (s == null) {
            return "";
        }
        String t = s.trim();
        while (!t.isEmpty()) {
            char last = t.charAt(t.length() - 1);
            if (last == '…' || last == '.' || last == '~' || last == '～' || last == '!'
                    || last == '！' || last == '。' || last == ' ' || last == '、' || last == '，'
                    || last == ':' || last == '：' || last == ';') {
                t = t.substring(0, t.length() - 1);
            } else {
                break;
            }
        }
        while (!t.isEmpty() && (t.charAt(0) == ' ' || t.charAt(0) == '\u3000'
                || t.charAt(0) == ':' || t.charAt(0) == '：')) {
            t = t.substring(1);
        }
        return t;
    }

    /** 归一化后的括号内容 → 命中的表情，未命中返回 null */
    private static String[] match(String content) {
        String[] exact = ALIAS.get(content);
        if (exact != null) {
            return exact;
        }
        String best = null;
        for (String alias : ALIAS.keySet()) {
            if (content.contains(alias)) {
                if (best == null || alias.length() > best.length()) {
                    best = alias;
                }
            }
        }
        if (best != null) {
            return ALIAS.get(best);
        }
        // 括号里比别名更短的情况，例如 (右看)；只在长度 >= 2 时反查，避免误命中
        if (content.length() >= 2) {
            for (Map.Entry<String, String[]> en : ALIAS.entrySet()) {
                if (en.getKey().contains(content)) {
                    return en.getValue();
                }
            }
        }
        return null;
    }

    public static Hit parse(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        int n = text.length();
        int i = 0;
        int guard = 0;
        while (i < n && guard++ < 512) {
            char c = text.charAt(i);
            if (c != '(' && c != '\uFF08') {
                i++;
                continue;
            }
            int j = i + 1;
            while (j < n) {
                char d = text.charAt(j);
                if (d == ')' || d == '\uFF09') {
                    break;
                }
                if (d == '(' || d == '\uFF08') {   // 嵌套视为噪音，跳过这个开括号重新扫
                    j = -1;
                    break;
                }
                j++;
            }
            if (j < 0) {
                i++;
                continue;
            }
            if (j >= n) {
                return null;                        // 括号没闭合，不匹配也不挂
            }
            String content = normalize(text.substring(i + 1, j));
            if (!content.isEmpty()) {
                String[] v = match(content);
                if (v != null) {
                    Hit h = new Hit();
                    h.state = v[0];
                    h.micro = v[1];
                    h.raw = text.substring(i + 1, j);
                    return h;
                }
            }
            i = j + 1;                              // 这个括号不认识，继续找下一个
        }
        return null;
    }

    public static String strip(String text) {
        if (text == null) {
            return "";
        }
        return text.replaceAll("[（(][^）)]{1,12}[）)]", "").replaceAll("\s{2,}", " ").trim();
    }
}
