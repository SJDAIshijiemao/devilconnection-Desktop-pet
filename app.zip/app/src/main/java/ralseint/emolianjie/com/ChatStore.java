package ralseint.emolianjie.com;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * 聊天记录永久保存：每个会话一个 JSON 文件（filesDir/sessions/<id>.json）。
 * 主设计要求“所有的对话都会永久保存，下次启动还可以直接读取上下文”，
 * “开启新对话且新旧不冲突”，因此按会话分文件，不覆盖历史。
 */
public final class ChatStore {

    /** kind: user / ai / notice（notice 是程序自动补发给 AI 的系统叙述，界面显示为浅灰） */
    public static class Msg {
        public String role;
        public String content;
        public long ts;
        public String kind;

        public Msg(String role, String content, String kind) {
            this.role = role;
            this.content = content;
            this.ts = System.currentTimeMillis();
            this.kind = kind;
        }

        Msg(JSONObject o) {
            role = o.optString("role");
            content = o.optString("content");
            kind = o.optString("kind", role.equals("user") ? "user" : "ai");
            ts = o.optLong("ts", System.currentTimeMillis());
        }

        JSONObject json() {
            JSONObject o = new JSONObject();
            try {
                o.put("role", role).put("content", content).put("kind", kind).put("ts", ts);
            } catch (Exception ignored) {
            }
            return o;
        }
    }

    private final File dir;
    private final Charset utf8 = Charset.forName("UTF-8");

    public ChatStore(Context c) {
        dir = new File(c.getApplicationContext().getFilesDir(), "sessions");
        if (!dir.isDirectory()) {
            dir.mkdirs();
        }
    }

    public List<String> sessions() {
        File[] fs = dir.listFiles();
        List<String> ids = new ArrayList<>();
        if (fs != null) {
            Arrays.sort(fs, new Comparator<File>() {
                @Override
                public int compare(File a, File b) {
                    return Long.compare(b.lastModified(), a.lastModified());
                }
            });
            for (File f : fs) {
                String n = f.getName();
                if (n.endsWith(".json")) {
                    ids.add(n.substring(0, n.length() - 5));
                }
            }
        }
        return ids;
    }

    public String create() {
        String id = "s" + System.currentTimeMillis();
        try {
            write(id, new JSONArray());
        } catch (Exception ignored) {
        }
        return id;
    }

    public String ensure(String id) {
        if (id == null || id.isEmpty() || !new File(dir, id + ".json").exists()) {
            return create();
        }
        return id;
    }

    public List<Msg> load(String id) {
        List<Msg> out = new ArrayList<>();
        try {
            File f = new File(dir, id + ".json");
            if (!f.exists()) {
                return out;
            }
            InputStream in = new FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int read = in.read(buf);
            in.close();
            JSONArray arr = new JSONArray(new String(buf, 0, Math.max(read, 0), utf8));
            for (int i = 0; i < arr.length(); i++) {
                out.add(new Msg(arr.getJSONObject(i)));
            }
        } catch (Exception e) {
            // 文件损坏时返回空列表，不抛出到 UI
        }
        return out;
    }

    public void append(String id, Msg m) {
        List<Msg> all = load(id);
        all.add(m);
        JSONArray arr = new JSONArray();
        for (Msg x : all) {
            arr.put(x.json());
        }
        write(id, arr);
    }

    public int count(String id) {
        return load(id).size();
    }

    public String title(String id) {
        List<Msg> all = load(id);
        for (Msg m : all) {
            if ("user".equals(m.kind)) {
                String s = m.content.replaceAll("\\s+", " ").trim();
                return s.length() > 14 ? s.substring(0, 14) : s;
            }
        }
        return "新对话";
    }

    private void write(String id, JSONArray arr) {
        try {
            File tmp = new File(dir, id + ".json.tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] data = arr.toString().getBytes(utf8);
            out.write(data);
            out.flush();
            out.close();
            File dst = new File(dir, id + ".json");
            if (dst.exists()) {
                dst.delete();
            }
            tmp.renameTo(dst);
        } catch (Exception ignored) {
        }
    }
}
