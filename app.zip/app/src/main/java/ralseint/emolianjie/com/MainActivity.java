package ralseint.emolianjie.com;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * 设置界面：纯白背景，左上角“手机的德比伦”，下面是 API/模型/上下文/思考开关、
 * 宠物与对话框大小、协议入口，以及“召唤德比伦”。所有改动即时写入 Prefs（自动保存）。
 */
public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 41;
    private static final int REQ_NOTI = 42;

    private Prefs prefs;
    private EditText urlBox, keyBox;
    private TextView modelLabel, statusLabel;
    private View ctxRow, petRow, dlgRow, autoRow, aliveRow;
    private Switch thinkSw, roamSw, soundSw;
    private Spinner providerSp;
    private boolean loading = true;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = new Prefs(this);
        buildUi();
        loading = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            updateStatus();
            if (canOverlay()) {
                summon();
            }
        }
    }

    // ------------------------------------------------------------- UI 构建

    @SuppressLint("SetTextI18n")
    private void buildUi() {
        loading = true;
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding((int) dp(18), (int) dp(18), (int) dp(18), (int) dp(28));
        scroll.addView(box, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText(getString(R.string.title_handset));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setTextColor(Color.parseColor("#111111"));
        title.setGravity(Gravity.START);
        box.addView(title);

        box.addView(section("API 与模型"));

        providerSp = new Spinner(this);
        List<String> labels = new ArrayList<>();
        for (String s : Prefs.PROVIDER_LABELS) {
            labels.add(s);
        }
        providerSp.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, labels));
        providerSp.setSelection(indexOf(prefs.provider()));
        providerSp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (loading) {
                    return;
                }
                String provider = Prefs.PROVIDER_IDS[pos];
                prefs.provider(provider);
                String old = prefs.baseUrl();
                if (old == null || old.trim().isEmpty() || old.trim().equals("http://")
                        || Prefs.defaultUrl(provider).equals(old)) {
                    String d = Prefs.defaultUrl(provider);
                    urlBox.setText(d);
                    prefs.baseUrl(d);
                }
                updateStatus();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> p) {
            }
        });
        box.addView(providerSp);

        box.addView(label("接口地址（支持 http 与 https）"));
        urlBox = edit(prefs.baseUrl(), false);
        box.addView(urlBox);

        box.addView(label("API Key（Ollama 可留空）"));
        keyBox = edit(prefs.apiKey(), false);
        box.addView(keyBox);

        Button fetch = fullButton("连接 API 并列出模型");
        fetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUrlKey();
                loadModels();
            }
        });
        box.addView(fetch);

        modelLabel = new TextView(this);
        modelLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        modelLabel.setTextColor(Color.parseColor("#333333"));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = (int) dp(6);
        box.addView(modelLabel, mlp);

        box.addView(section("上下文与思考"));

        ctxRow = seek(2, 40, prefs.contextLimit(), "上下文条数上限：%d");
        box.addView(ctxRow);

        thinkSw = aSwitch("禁用思考（省时间/省 token）", prefs.disableThinking());
        box.addView(thinkSw);

        box.addView(section("界面大小"));

        petRow = seek(40, 260, prefs.petScale(), "宠物大小：%d%%");
        box.addView(petRow);

        dlgRow = seek(UiSize.MIN_DIALOG_SCALE, UiSize.MAX_DIALOG_SCALE, prefs.dialogScale(), "对话框大小：%d%%");
        box.addView(dlgRow);

        box.addView(section("行为"));

        autoRow = seek(1, 15, prefs.autoTalkMinutes(), "静默 %d 分钟后 AI 主动搭话");
        box.addView(autoRow);

        aliveRow = seek(1, 15, prefs.keepAliveMinutes(), "每 %d 分钟向服务器保活一次");
        box.addView(aliveRow);

        roamSw = aSwitch("让德比伦四处游走", prefs.roaming());
        box.addView(roamSw);

        soundSw = aSwitch("说话时播放 po.mp3 音效", prefs.sound());
        box.addView(soundSw);

        box.addView(section("权限与协议"));

        Button usage = fullButton("打开“使用情况访问权限”（用于检测抖音/快手）");
        usage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception e) {
                    toast("这个系统没有找到usage access 设置页");
                }
            }
        });
        box.addView(usage);

        Button ag1 = fullButton("查看软件协议");
        ag1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAgreement("agreement_software.txt", "软件协议");
            }
        });
        box.addView(ag1);

        Button ag2 = fullButton("查看用户声明（含调试按钮）");
        ag2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAgreement("agreement_user.txt", "用户声明", true);
            }
        });
        box.addView(ag2);

        statusLabel = new TextView(this);
        statusLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        statusLabel.setTextColor(Color.parseColor("#666666"));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.topMargin = (int) dp(10);
        box.addView(statusLabel, slp);

        Button summonBtn = fullButton("召唤德比伦");
        summonBtn.setBackgroundColor(Color.parseColor("#222222"));
        summonBtn.setTextColor(Color.WHITE);
        summonBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUrlKey();
                if (!canOverlay()) {
                    toast("请先允许悬浮窗权限");
                    try {
                        startActivityForResult(new Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
                    } catch (Exception e) {
                        toast("打不开悬浮窗设置页");
                    }
                    return;
                }
                summon();
            }
        });
        box.addView(summonBtn);

        Button recall = fullButton("收回德比伦");
        recall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, PetService.class);
                i.setAction(PetService.ACTION_RECALL);
                startService(i);
            }
        });
        box.addView(recall);

        Button newChat = fullButton("开一段新对话");
        newChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.session(new ChatStore(MainActivity.this).create());
                toast("已切到新会话");
                refreshService();
            }
        });
        box.addView(newChat);

        refreshLabels();
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t.setTextColor(Color.parseColor("#777777"));
        return t;
    }

    private TextView section(String s) {
        TextView t = new TextView(this);
        t.setText("— " + s + " —");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTextColor(Color.parseColor("#111111"));
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) dp(18);
        lp.bottomMargin = (int) dp(4);
        t.setLayoutParams(lp);
        return t;
    }

    private EditText edit(String val, boolean number) {
        EditText e = new EditText(this);
        e.setText(val == null ? "" : val);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        e.setInputType(number ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
        e.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        e.setLayoutParams(lp);
        return e;
    }

    private Button fullButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) dp(44));
        lp.topMargin = (int) dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    /** 一行：标题 + 拖动条，改动即写入 Prefs */
    private View seek(final int lo, int max, int value, final String fmt) {
        final LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        final TextView tv = label(String.format(fmt, value));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - lo);
        sb.setProgress(Math.max(0, Math.min(value - lo, max - lo)));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = lo + p;
                tv.setText(String.format(fmt, v));
                if (!loading) {
                    applySeek(fmt, v);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                refreshService();
            }
        });
        wrap.addView(tv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        wrap.addView(sb);
        return wrap;
    }

    /** 拖动条的百分比/条数按标题文案归到对应设置项 */
    private void applySeek(String fmt, int v) {
        if (fmt.contains("上下文")) {
            prefs.contextLimit(v);
        } else if (fmt.contains("宠物")) {
            prefs.petScale(v);
        } else if (fmt.contains("对话框")) {
            prefs.dialogScale(v);
        } else if (fmt.contains("主动搭话")) {
            prefs.autoTalkMinutes(v);
        } else if (fmt.contains("保活")) {
            prefs.keepAliveMinutes(v);
        }
    }

    private Switch aSwitch(String text, boolean value) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        s.setChecked(value);
        final String tag = text;
        s.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                if (loading) {
                    return;
                }
                if (tag.contains("思考")) {
                    prefs.disableThinking(checked);
                } else if (tag.contains("游走")) {
                    prefs.roaming(checked);
                } else if (tag.contains("po.mp3")) {
                    prefs.sound(checked);
                }
                refreshService();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) dp(6);
        s.setLayoutParams(lp);
        return s;
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private int indexOf(String provider) {
        for (int i = 0; i < Prefs.PROVIDER_IDS.length; i++) {
            if (Prefs.PROVIDER_IDS[i].equals(provider)) {
                return i;
            }
        }
        return 0;
    }

    // ------------------------------------------------------------- 动作

    private void saveUrlKey() {
        prefs.baseUrl(urlBox.getText().toString().trim());
        prefs.apiKey(keyBox.getText().toString().trim());
    }

    private void loadModels() {
        AiClient.Config c = AiClient.Config.of(prefs);
        toast("正在连接 " + c.base);
        new AiClient().models(c, new AiClient.OnModels() {
            @Override
            public void done(final List<String> models, String err) {
                if (err != null) {
                    toast("列模型失败：" + err);
                    return;
                }
                if (models.isEmpty()) {
                    toast("接口没返回任何模型");
                    return;
                }
                String[] arr = models.toArray(new String[0]);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("选择模型（自动加载）")
                        .setItems(arr, new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int which) {
                                prefs.model(models.get(which));
                                refreshLabels();
                                toast("已加载 " + models.get(which));
                            }
                        })
                        .show();
            }
        });
    }

    private void summon() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(
                android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
        }
        Intent i = new Intent(this, PetService.class);
        i.setAction(PetService.ACTION_SUMMON);
        try {
            startService(i);
        } catch (Exception e) {
            toast("启动服务失败：" + e.getMessage());
            return;
        }
        hideKeyboard();
        moveTaskToBack(true);
    }

    private void refreshService() {
        try {
            Intent i = new Intent(this, PetService.class);
            i.setAction(PetService.ACTION_REFRESH);
            startService(i);
        } catch (Exception ignored) {
        }
    }

    private void refreshLabels() {
        String m = prefs.model();
        modelLabel.setText("当前模型：" + (m.isEmpty() ? "（还没选）" : m)
                + "\n接口：" + prefs.baseUrl()
                + "\n会话：" + prefs.session());
    }

    private void updateStatus() {
        refreshLabels();
        StringBuilder sb = new StringBuilder();
        sb.append(canOverlay() ? "悬浮窗：已授权" : "悬浮窗：未授权（必须开）");
        sb.append("\n");
        sb.append(canUsage() ? "使用情况：已授权（可检测抖音/快手）" : "使用情况：未授权（检测功能不生效）");
        statusLabel.setText(sb.toString());
    }

    private boolean canOverlay() {
        if (Build.VERSION.SDK_INT >= 23) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }

    private boolean canUsage() {
        try {
            android.app.AppOpsManager ops = (android.app.AppOpsManager)
                    getSystemService(Context.APP_OPS_SERVICE);
            if (ops == null) {
                return false;
            }
            int mode;
            if (Build.VERSION.SDK_INT >= 29) {
                mode = ops.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), getPackageName());
            } else {
                mode = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), getPackageName());
            }
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private void showAgreement(String asset, String title) {
        showAgreement(asset, title, false);
    }

    /** withDebug=true 时附一个调试按钮，点了直接让德比伦输出测试文本 */
    private void showAgreement(String asset, String title, boolean withDebug) {
        String body = readAsset(asset);
        TextView tv = new TextView(this);
        tv.setText(body == null || body.isEmpty() ? "（没找到" + title + "文本）" : body);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setPadding((int) dp(12), (int) dp(12), (int) dp(12), (int) dp(12));
        ScrollView sc = new ScrollView(this);
        sc.addView(tv);
        AlertDialog.Builder bd = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(sc)
                .setPositiveButton("知道了", null);
        if (withDebug) {
            bd.setNeutralButton("测试德比伦", new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface d, int which) {
                    runDebugDemo();
                }
            });
        }
        bd.show();
    }

    /** 调试：先确保德比伦在桌面上，再让它按顺序输出一条测试文本 */
    private void runDebugDemo() {
        try {
            Intent summon = new Intent(this, PetService.class);
            summon.setAction(PetService.ACTION_SUMMON);
            startService(summon);
            Intent debug = new Intent(this, PetService.class);
            debug.setAction(PetService.ACTION_DEBUG);
            startService(debug);
            toast("已让德比伦输出测试文本，留意音效和贴图");
            moveTaskToBack(true);
        } catch (Exception e) {
            toast("调试失败：" + e.getMessage());
        }
    }

    private String readAsset(String name) {
        try {
            java.io.InputStream in = getAssets().open(name);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) > 0) {
                bo.write(buf, 0, r);
            }
            in.close();
            return new String(bo.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null && getCurrentFocus() != null) {
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            }
        } catch (Exception ignored) {
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
