package ralseint.emolianjie.com;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 所有设置的读写入口。主设计要求“所有的设置都会自动保存进软件”，
 * 因此这里统一走 SharedPreferences，UI 侧改动即落盘，无需保存按钮。
 */
public final class Prefs {

    public static final String P_OLLAMA = "ollama";
    public static final String P_GPT = "gpt";
    public static final String P_DEEPSEEK = "deepseek";
    public static final String P_QWEN = "qianwen";
    public static final String P_CUSTOM = "custom";

    public static final String[] PROVIDER_LABELS = {
            "Ollama（本地/局域网）", "OpenAI GPT", "DeepSeek", "通义千问", "自定义 OpenAI 兼容接口"};
    public static final String[] PROVIDER_IDS = {P_OLLAMA, P_GPT, P_DEEPSEEK, P_QWEN, P_CUSTOM};

    public static String defaultUrl(String provider) {
        switch (provider) {
            case P_GPT: return "https://api.openai.com/v1";
            case P_DEEPSEEK: return "https://api.deepseek.com/v1";
            case P_QWEN: return "https://dashscope.aliyuncs.com/compatible-mode/v1";
            case P_OLLAMA: return "http://127.0.0.1:11434";
            default: return "http://";
        }
    }

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("ralseint_prefs", Context.MODE_PRIVATE);
    }

    public String provider() { return sp.getString("provider", P_OLLAMA); }
    public void provider(String v) { sp.edit().putString("provider", v).apply(); }

    public String baseUrl() { return sp.getString("base_url", defaultUrl(provider())); }
    public void baseUrl(String v) { sp.edit().putString("base_url", v).apply(); }

    public String apiKey() { return sp.getString("api_key", ""); }
    public void apiKey(String v) { sp.edit().putString("api_key", v).apply(); }

    public String model() { return sp.getString("model", ""); }
    public void model(String v) { sp.edit().putString("model", v).apply(); }

    /** 上下文条数上限（主设计：选完链接之后可以调整上下文限制） */
    public int contextLimit() { return sp.getInt("context_limit", 12); }
    public void contextLimit(int v) { sp.edit().putInt("context_limit", v).apply(); }

    public boolean disableThinking() { return sp.getBoolean("disable_thinking", true); }
    public void disableThinking(boolean v) { sp.edit().putBoolean("disable_thinking", v).apply(); }

    /** 宠物大小百分比，40~260 */
    public int petScale() { return sp.getInt("pet_scale", 100); }
    public void petScale(int v) { sp.edit().putInt("pet_scale", clamp(v, 40, 260)).apply(); }

    /** 对话框大小百分比，60~200 */
    public int dialogScale() { return sp.getInt("dialog_scale", UiSize.DEFAULT_DIALOG_SCALE); }
    public void dialogScale(int v) { sp.edit().putInt("dialog_scale", clamp(v, UiSize.MIN_DIALOG_SCALE, UiSize.MAX_DIALOG_SCALE)).apply(); }

    public boolean roaming() { return sp.getBoolean("roaming", true); }
    public void roaming(boolean v) { sp.edit().putBoolean("roaming", v).apply(); }

    public boolean sound() { return sp.getBoolean("sound", true); }
    public void sound(boolean v) { sp.edit().putBoolean("sound", v).apply(); }

    /** 静默多久后 AI 主动搭话（分钟） */
    public int autoTalkMinutes() { return sp.getInt("auto_talk_minutes", 2); }
    public void autoTalkMinutes(int v) { sp.edit().putInt("auto_talk_minutes", clamp(v, 1, 60)).apply(); }

    /** 保活请求间隔（分钟），防止服务器上的 AI 休眠 */
    public int keepAliveMinutes() { return sp.getInt("keep_alive_minutes", 4); }
    public void keepAliveMinutes(int v) { sp.edit().putInt("keep_alive_minutes", clamp(v, 1, 60)).apply(); }

    public String session() { return sp.getString("session", ""); }
    public void session(String v) { sp.edit().putString("session", v).apply(); }

    public int petX() { return sp.getInt("pet_x", -1); }
    public int petY() { return sp.getInt("pet_y", -1); }
    public void petPos(int x, int y) { sp.edit().putInt("pet_x", x).putInt("pet_y", y).apply(); }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
