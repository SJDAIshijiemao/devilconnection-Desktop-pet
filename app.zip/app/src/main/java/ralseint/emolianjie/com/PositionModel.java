package ralseint.emolianjie.com;

/**
 * 宠物位置的单一数据源（纯逻辑，可单元测试）。
 *
 * 回归的 bug：浮动动画与拖动/漫游同时直接写 window 坐标，动画每帧把 y 冲回基准，
 * 垂直拖动立刻弹回出生点，表现为"德比伦只能在屏幕中间动"。
 * 现在只有 setBase 能改基准（拖动、漫游），浮动偏移只叠加在最终输出上，不回写基准。
 */
public final class PositionModel {

    private int baseX;
    private int baseY;
    private int floatOffset;

    private int screenW;
    private int screenH;
    private int petW = 1;
    private int petH = 1;
    private int topMargin;
    private int bottomMargin;

    public void setBounds(int screenW, int screenH, int petW, int petH,
                          int topMargin, int bottomMargin) {
        this.screenW = screenW;
        this.screenH = screenH;
        this.petW = Math.max(1, petW);
        this.petH = Math.max(1, petH);
        this.topMargin = Math.max(0, topMargin);
        this.bottomMargin = Math.max(0, bottomMargin);
    }

    /** 拖动或漫游设定的落脚位，唯一可写的基准 */
    public void setBase(int x, int y) {
        baseX = x;
        baseY = y;
    }

    /** 只记录浮动偏移，绝不改写基准 */
    public void setFloatOffset(int offset) {
        floatOffset = offset;
    }

    public int baseX() {
        return baseX;
    }

    public int baseY() {
        return baseY;
    }

    public int minX() {
        return 0;
    }

    public int maxX() {
        return Math.max(0, screenW - petW);
    }

    public int minY() {
        return topMargin;
    }

    public int maxY() {
        return Math.max(topMargin, screenH - petH - bottomMargin);
    }

    public int clampX(int x) {
        return Math.min(maxX(), Math.max(minX(), x));
    }

    public int clampY(int y) {
        return Math.min(maxY(), Math.max(minY(), y));
    }

    public int x() {
        return clampX(baseX);
    }

    public int y() {
        return clampY(baseY + floatOffset);
    }
}
