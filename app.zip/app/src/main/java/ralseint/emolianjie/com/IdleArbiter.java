package ralseint.emolianjie.com;

/**
 * 冷场判定：把"最后一次任何活动"作为基准，用户发言和 AI 回复都算活动。
 * 只盯用户发言会导致刚聊完一轮就被判定冷场（用户报的现象之一）。
 * 触发后调用方会把 lastUserTs 推到当前时间，形成迟滞，避免连续抢话。
 */
public final class IdleArbiter {

    public static boolean shouldSpeakNow(long now, long lastUserTs, long lastAiTs,
                                         boolean busy, boolean petVisible, long limitMs) {
        if (!petVisible || busy) {
            return false;
        }
        long lastActivity = Math.max(lastUserTs, lastAiTs);
        return now - lastActivity > limitMs;
    }
}
