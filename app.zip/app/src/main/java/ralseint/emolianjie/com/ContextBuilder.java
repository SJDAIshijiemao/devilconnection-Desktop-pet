package ralseint.emolianjie.com;

import java.util.ArrayList;
import java.util.List;

/**
 * 组装发给模型的上下文。
 *
 * 关键约束（回归用户报的"刚说话还被提醒冷场"）：
 * 程序旁白 kind=notice 只用于界面展示，绝不能以 role=user 的身份进入上下文，
 * 否则"已经2分钟没说话"这类一次性指令会被模型当成召唤师的原话反复复读。
 * 需要告知模型的事，改用一次性 system 轮次，用完即焚。
 */
public final class ContextBuilder {

    public static class Turn {
        public final String role;
        public final String content;

        public Turn(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    public static List<Turn> build(String systemRule, List<ChatStore.Msg> msgs, int limit,
                                   String pendingInstruction) {
        List<Turn> out = new ArrayList<>();
        out.add(new Turn("system", systemRule == null || systemRule.isEmpty()
                ? "你是德比伦，说话短句、口语化。" : systemRule));
        List<ChatStore.Msg> real = new ArrayList<>();
        for (ChatStore.Msg m : msgs) {
            if (!"notice".equals(m.kind)) {
                real.add(m);
            }
        }
        int n = Math.max(2, limit);
        int from = Math.max(0, real.size() - n);
        for (int i = from; i < real.size(); i++) {
            ChatStore.Msg m = real.get(i);
            out.add(new Turn(m.role, m.content));
        }
        if (pendingInstruction != null && !pendingInstruction.isEmpty()) {
            out.add(new Turn("system", pendingInstruction));
        }
        return out;
    }
}
