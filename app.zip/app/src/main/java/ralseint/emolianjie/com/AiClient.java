package ralseint.emolianjie.com;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 统一的 API 客户端。四个预设（Ollama / OpenAI GPT / DeepSeek / 通义千问）
 * 都走 OpenAI 兼容协议，Ollama 额外支持 /api/tags 与 think 开关；
 * 地址允许 http 与 https（主设计要求），需要鉴权的填 API Key。
 */
public final class AiClient {

    public interface OnReply {
        /** text 为模型正文，err 非空表示失败 */
        void done(String text, String err);
    }

    public interface OnModels {
        void done(List<String> models, String err);
    }

    public interface OnPing {
        void done(boolean alive, String err);
    }

    public static class Config {
        public String base = "";
        public String provider = Prefs.P_OLLAMA;
        public String key = "";
        public String model = "";
        public boolean disableThinking = true;
        public int contextLimit = 12;

        public static Config of(Prefs p) {
            Config c = new Config();
            c.base = trimSlash(p.baseUrl());
            c.provider = p.provider();
            c.key = p.apiKey();
            c.model = p.model();
            c.disableThinking = p.disableThinking();
            c.contextLimit = p.contextLimit();
            return c;
        }

        public boolean ollama() {
            return Prefs.P_OLLAMA.equals(provider);
        }
    }

    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private static final Charset UTF8 = Charset.forName("UTF-8");

    public void chat(final Config cfg, final JSONArray messages, final OnReply cb) {
        pool.execute(new Runnable() {
            @Override
            public void run() {
                final String[] res = new String[2];
                try {
                    res[0] = doChat(cfg, messages);
                } catch (Exception e) {
                    res[1] = e.getClass().getSimpleName() + ": " + e.getMessage();
                }
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(res[0], res[1]);
                    }
                });
            }
        });
    }

    public void models(final Config cfg, final OnModels cb) {
        pool.execute(new Runnable() {
            @Override
            public void run() {
                final List<String> list = new ArrayList<>();
                String err = null;
                try {
                    String url = cfg.ollama() ? cfg.base + "/api/tags" : cfg.base + "/models";
                    String body = get(url, cfg.key);
                    JSONObject o = new JSONObject(body);
                    if (cfg.ollama()) {
                        JSONArray arr = o.optJSONArray("models");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) {
                                list.add(arr.getJSONObject(i).optString("name"));
                            }
                        }
                    } else {
                        JSONArray arr = o.optJSONArray("data");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) {
                                list.add(arr.getJSONObject(i).optString("id"));
                            }
                        }
                    }
                } catch (Exception e) {
                    err = e.getClass().getSimpleName() + ": " + e.getMessage();
                }
                final String ferr = err;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(list, ferr);
                    }
                });
            }
        });
    }

    /** 保活：主设计要求定时向服务器发一个请求，防止远端 AI 休眠 */
    public void ping(final Config cfg, final OnPing cb) {
        pool.execute(new Runnable() {
            @Override
            public void run() {
                String err = null;
                try {
                    String url = cfg.ollama() ? cfg.base + "/api/tags" : cfg.base + "/models";
                    get(url, cfg.key);
                } catch (Exception e) {
                    err = e.getMessage();
                }
                final boolean ok = err == null;
                final String ferr = err;
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(ok, ferr);
                    }
                });
            }
        });
    }

    private String doChat(Config cfg, JSONArray messages) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", cfg.model);
        body.put("messages", messages);
        body.put("stream", false);
        if (cfg.ollama()) {
            JSONObject opt = new JSONObject();
            opt.put("num_ctx", Math.max(2048, cfg.contextLimit * 512));
            body.put("options", opt);
            if (cfg.disableThinking) {
                // Ollama 新版支持顶层 think 字段
                body.put("think", false);
            }
        } else if (Prefs.P_QWEN.equals(cfg.provider) && cfg.disableThinking) {
            body.put("enable_thinking", false);
        }
        String url = cfg.ollama() ? cfg.base + "/api/chat" : cfg.base + "/chat/completions";
        String resp = post(url, cfg.key, body.toString());
        JSONObject o = new JSONObject(resp);
        String text;
        if (cfg.ollama() && o.has("message")) {
            text = o.getJSONObject("message").optString("content");
        } else {
            JSONArray ch = o.optJSONArray("choices");
            if (ch == null || ch.length() == 0) {
                throw new Exception("返回里没有 choices：" + brief(resp));
            }
            JSONObject msg = ch.getJSONObject(0).optJSONObject("message");
            if (msg == null) {
                text = ch.getJSONObject(0).optString("text");
            } else {
                text = msg.optString("content");
                if (text == null || text.trim().isEmpty()) {
                    text = msg.optString("reasoning_content");
                }
            }
        }
        if (text == null) {
            throw new Exception("模型没有返回正文");
        }
        return text.trim();
    }

    private static String trimSlash(String s) {
        if (s == null) {
            return "";
        }
        String t = s.trim();
        while (t.endsWith("/")) {
            t = t.substring(0, t.length() - 1);
        }
        return t;
    }

    private static String brief(String s) {
        if (s == null) {
            return "null";
        }
        return s.length() > 160 ? s.substring(0, 160) + "…" : s;
    }

    private String get(String url, String key) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        if (key != null && !key.isEmpty()) {
            c.setRequestProperty("Authorization", "Bearer " + key);
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String body = readAll(in);
        if (code >= 400) {
            throw new Exception("HTTP " + code + " " + brief(body));
        }
        return body;
    }

    private String post(String url, String key, String payload) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(12000);
        c.setReadTimeout(90000);
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        c.setRequestProperty("Accept", "application/json");
        if (key != null && !key.isEmpty()) {
            c.setRequestProperty("Authorization", "Bearer " + key);
        }
        OutputStream os = c.getOutputStream();
        os.write(payload.getBytes(UTF8));
        os.flush();
        os.close();
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String body = readAll(in);
        c.disconnect();
        if (code >= 400) {
            throw new Exception("HTTP " + code + " " + brief(body));
        }
        return body;
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) {
            return "";
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(in, UTF8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) {
            sb.append(line);
        }
        r.close();
        return sb.toString();
    }
}
