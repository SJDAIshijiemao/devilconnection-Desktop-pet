package ralseint.emolianjie.com;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * 表情贴图仓库：读取 assets/sprites/manifest.json（由 tools_prep_assets.py 生成），
 * 按状态随机取图并做内存缓存。中文素材目录已在打包阶段改成 ASCII，这里不再依赖中文路径。
 */
public final class SpriteStore {

    public static final String S_IDLE = "idle";
    public static final String S_EAT = "eat";
    public static final String S_ANGRY = "angry";
    public static final String S_LAZY = "lazy";
    public static final String S_HAPPY = "happy";
    public static final String S_ZAYU = "zayu";
    public static final String S_LOOK_LEFT = "look_left";
    public static final String S_LOOK_RIGHT = "look_right";
    public static final String S_DAZED = "dazed";
    public static final String S_MAGIC = "magic";
    public static final String S_SURPRISE = "surprise";
    public static final String S_SCARE = "scare";
    public static final String S_THINK = "think";

    private final Context ctx;
    private final Map<String, List<String>> states = new HashMap<>();
    private final List<String> done = new ArrayList<>();
    private final Map<String, String> micro = new HashMap<>();
    private final List<String> microKeys = new ArrayList<>();
    private final LruCache<String, Bitmap> cache;
    private final Random rnd = new Random();

    public SpriteStore(Context c) {
        this.ctx = c.getApplicationContext();
        int maxMem = (int) (Runtime.getRuntime().maxMemory() / 1024);
        cache = new LruCache<String, Bitmap>(maxMem / 3) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };
        load();
    }

    private void load() {
        try {
            String json;
            InputStream in = ctx.getAssets().open("sprites/manifest.json");
            byte[] buf = new byte[in.available()];
            int read = in.read(buf);
            in.close();
            json = new String(buf, 0, Math.max(read, 0), "UTF-8");
            JSONObject root = new JSONObject(json);
            JSONObject st = root.getJSONObject("states");
            java.util.Iterator<String> it = st.keys();
            while (it.hasNext()) {
                String k = it.next();
                List<String> list = new ArrayList<>();
                org.json.JSONArray arr = st.getJSONArray(k);
                for (int i = 0; i < arr.length(); i++) {
                    String path = "sprites/" + arr.getString(i).substring("sprites/".length());
                    list.add(arr.getString(i));
                }
                states.put(k, list);
            }
            List<String> eats = states.get(S_EAT);
            if (eats != null) {
                for (String p : new ArrayList<>(eats)) {
                    if (p.contains("/done")) {
                        done.add(p);
                        eats.remove(p);
                    }
                }
            }
            JSONObject mi = root.optJSONObject("micro");
            if (mi != null) {
                java.util.Iterator<String> m = mi.keys();
                while (m.hasNext()) {
                    String k = m.next();
                    micro.put(k, mi.getString(k));
                    microKeys.add(k);
                }
            }
        } catch (Exception e) {
            // manifest 缺失时兜底：内置常见路径，保证不会崩
            List<String> l = new ArrayList<>();
            l.add("sprites/idle/idle1.png");
            states.put(S_IDLE, l);
        }
    }

    /** 取某状态的随机一张；状态没有贴图时回落至待机 */
    public Bitmap pick(String state) {
        List<String> l = states.get(state);
        if (l == null || l.isEmpty()) {
            l = states.get(S_IDLE);
        }
        if (l == null || l.isEmpty()) {
            return null;
        }
        return bitmap(l.get(rnd.nextInt(l.size())));
    }

    /** 吃东西吃完后的随机一张 */
    public Bitmap pickEaten() {
        if (!done.isEmpty()) {
            return bitmap(done.get(rnd.nextInt(done.size())));
        }
        return pick(S_IDLE);
    }

    public Bitmap micro(String key) {
        String p = micro.get(key);
        return p == null ? null : bitmap(p);
    }

    /** 5 秒轮播用：随机挑一个右上角小表情 */
    public String randomMicroKey() {
        if (microKeys.isEmpty()) {
            return null;
        }
        return microKeys.get(rnd.nextInt(microKeys.size()));
    }

    public boolean hasMicro(String key) {
        return micro.containsKey(key);
    }

    public boolean hasState(String state) {
        List<String> l = states.get(state);
        return l != null && !l.isEmpty();
    }

    private Bitmap bitmap(String path) {
        Bitmap b = cache.get(path);
        if (b != null && !b.isRecycled()) {
            return b;
        }
        try {
            InputStream in = ctx.getAssets().open(path);
            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
            b = BitmapFactory.decodeStream(in, null, opt);
            in.close();
            if (b != null) {
                cache.put(path, b);
            }
        } catch (Exception e) {
            return null;
        }
        return b;
    }
}
