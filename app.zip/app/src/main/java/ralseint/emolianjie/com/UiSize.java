package ralseint.emolianjie.com;

/**
 * 悬浮对话框的尺寸基准。原来基准 310x360dp 且默认 100%，在小屏上几乎盖住半屏，
 * 现按用户反馈缩小基准并把默认档降到 80%。
 */
public final class UiSize {

    public static final int BASE_DIALOG_W_DP = 250;
    public static final int BASE_DIALOG_H_DP = 290;

    public static final int MIN_DIALOG_SCALE = 62;
    public static final int DEFAULT_DIALOG_SCALE = 80;
    public static final int MAX_DIALOG_SCALE = 200;

    public static int dialogWidthDp(int scale) {
        return BASE_DIALOG_W_DP * clampScale(scale) / 100;
    }

    public static int dialogHeightDp(int scale) {
        return BASE_DIALOG_H_DP * clampScale(scale) / 100;
    }

    private static int clampScale(int s) {
        return Math.min(MAX_DIALOG_SCALE, Math.max(MIN_DIALOG_SCALE, s));
    }
}
